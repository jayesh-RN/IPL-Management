import React from 'react'

const Banner = () => {
  return (
      
    <>
      <div style={{textAlign:"center"}}>
      <h1>Banner</h1>
      <img src="https://lawbhoomi.com/wp-content/uploads/2023/11/sportz-interactive.webp" alt="Sportz interactive"  style={{alignContent:"center"}}></img>
      </div>
    </>
  )
}

export default Banner